﻿using ProductsDiApi.Models;

namespace ProductsDiApi.Services
{
    public class ProductService : IProductService
    {
        private readonly List<Product> _products = new()
        {
            new Product { Id = 1, Name = "Ноутбук", Price = 350000m },
            new Product { Id = 2, Name = "Мышь", Price = 5000m },
            new Product { Id = 3, Name = "Клавиатура", Price = 12000m }
        };

        private int _nextId = 4;

        public IEnumerable<Product> GetAll()
        {
            return _products;
        }

        public Product? GetById(int id)
        {
            return _products.FirstOrDefault(p => p.Id == id);
        }

        public Product Add(Product product)
        {
            product.Id = _nextId++;
            _products.Add(product);
            return product;
        }

        public bool Delete(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            if (product == null)
            {
                return false;
            }

            _products.Remove(product);
            return true;
        }
    }
}