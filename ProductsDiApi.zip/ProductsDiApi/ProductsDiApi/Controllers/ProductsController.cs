﻿using Microsoft.AspNetCore.Mvc;
using ProductsDiApi.Models;
using ProductsDiApi.Services;

namespace ProductsDiApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;
        private readonly ILogger<ProductsController> _logger;

        public ProductsController(IProductService productService, ILogger<ProductsController> logger)
        {
            _productService = productService;
            _logger = logger;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Product>> GetAll()
        {
            _logger.LogInformation("Getting all products");
            var products = _productService.GetAll();
            return Ok(products);
        }

        [HttpGet("{id}")]
        public ActionResult<Product> GetById(int id)
        {
            try
            {
                var product = _productService.GetById(id);

                if (product == null)
                {
                    _logger.LogWarning("Product with ID {ProductId} was not found", id);
                    return NotFound();
                }

                _logger.LogInformation("Product with ID {ProductId} was found", id);
                return Ok(product);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while processing product with ID {ProductId}", id);
                return StatusCode(500, "Произошла внутренняя ошибка сервера.");
            }
        }

        [HttpPost]
        public ActionResult<Product> Create(Product product)
        {
            if (product == null || string.IsNullOrWhiteSpace(product.Name) || product.Price <= 0)
            {
                return BadRequest();
            }

            var created = _productService.Add(product);
            _logger.LogInformation("Product {ProductName} was created", created.Name);

            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var deleted = _productService.Delete(id);

            if (!deleted)
            {
                _logger.LogWarning("Product with ID {ProductId} was not found", id);
                return NotFound();
            }

            _logger.LogInformation("Product with ID {ProductId} was deleted", id);
            return Ok();
        }
    }
}